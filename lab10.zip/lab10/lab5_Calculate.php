<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->



<?php
	$title = "Calculated Number";
	$file = "lab5_Calculate.php";
	$description = "Description: This will get its information from the Calculate form page and display the answer here";
	$date = "Date: March 4th, 2022";
	$banner = "Calculated Answer";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>


<?php

    if (($_POST['val1'] == "") || ($_POST['val2'] == "") || ($_POST['calc'] =="")) {
        // If the text boxes for val1 or 2 are empty then it goes back to the calculate form page.
        header("Location: lab5_Calculate_form.php");
        exit;
    }

    //If the numbers are filled in and the 'add' is selected, then add the 2 number together and show the answer
    if ($_POST['calc'] == "add") {
        $result = $_POST['val1'] + $_POST['val2'];
        //If the numbers are filled in and the 'subtract' is selected, then subtract the 2 number together and show the answer
    } else if ($_POST['calc'] == "subtract") {
        $result = $_POST['val1'] - $_POST['val2'];
        //If the numbers are filled in and the 'multiply' is selected, then multiply the 2 number together and show the answer
    } else if ($_POST['calc'] == "multiply") {
        $result = $_POST['val1'] * $_POST['val2'];
        //If the numbers are filled in and the 'divide' is selected, then divide the 2 number together and show the answer
    } else if ($_POST['calc'] == "divide") {
        $result = $_POST['val1'] / $_POST['val2'];
    }
?>
<!--          MAIN CONTENT INSIDE HERE        -->

<p>
    This webpage is here to display the calculation recieved by the webpage "Calculate Form." This page is strictly just to give the answer from that page. <br/><br/>

    <!-- Display the result -->
    The result of the calculation is:<?php echo " $result";?>


</p>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>