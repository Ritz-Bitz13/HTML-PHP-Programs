		<!-- end of main page content -->
		</div>		
		<div id="footer">
		<!-- start of footer -->
				<a href="http://validator.w3.org/check?uri=referer">
					<img 	style="width:88px;
								height:31px;"
							src="http://www.w3.org/Icons/valid-xhtml10" 
							alt="Valid XHTML 1.0 Strict" />
				</a>
  			   	<a href="http://jigsaw.w3.org/css-validator/check/referer">
			        	<img 	style="width:88px;
									height:31px;"
        			    		src="http://jigsaw.w3.org/css-validator/images/vcss"
								alt="Valid CSS!" />
    			</a>
				 <?php display_copyright($your_name, $year) ?> <!-- Copyright signoff new to test 2. This will show my name and the year I completed this -->
		<!-- end of footer -->
		</div>
	</div>
</div>

</body>
</html>