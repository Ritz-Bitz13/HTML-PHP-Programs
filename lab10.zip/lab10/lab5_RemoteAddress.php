<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Remote Address";
	$file = "lab5_RemoteAddress.php";
	$description = "Description: This will show the Local IP Address";
	$date = "Date: March 4th, 2022";
	$banner = "Your Remote Address";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<p>
    This Part of the lab will show the local IP being used to view the webpage at this moment. By using a simple text of "REMOTE_ADDR" you can show the IP.

    
    <?php 
    // This variable will use a built in function to get the IP address
        $address = getenv("REMOTE_ADDR");
        // When you echo the variable it will display the address to the web page.
        echo "<br/> <br/> Your IP Address is $address.";
    ?>
</p>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


