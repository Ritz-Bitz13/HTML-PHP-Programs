<?php
	$title = "Lab 4";
	$file = "lab4.php";
	$description = "Description: Lab 4: Intro to PHP";
	$date = "Date: February 18, 2022";
	$banner = "Lab 4 - Intro to PHP";
    $your_name = "Martin Barber";
    $year = "2022";
    //insert the header
	include('header.php');
?>

<ol>
    <!--  All the links to go to the other pages  -->
    <li><a href="./lab4tag.php" >PHP Start and End Tags (Chapter 4)</a></li>
    <li><a href="./lab4Cohabition.php" >Code Cohabitation (Chapter 4)</a></li>
    <li><a href="./lab4Escape.php" >Escaping Your Code (Chapter 4)</a></li>
    <li><a href="./lab4Comment.php" >Commenting Your Code (Chapter 4)</a></li>
    <li><a href="./lab4Types.php" >PHP Variable and Value Types (Chapter 5)</a></li>
    <li><a href="./lab4Constants1.php" >Using Constants (Chapter 5)</a></li>
    <li><a href="./lab4Constants2.php" >Using Constants 2 (Chapter 5) untitled section in Using Constants section, refers to constants2.php</a></li>
    <li><a href="./lab4AssignOps.php" >Assignment Operators (Chapter 5)</a></li>
    <li><a href="./lab4ArithOps.php" >Arithmetic Operators (Chapter 5)</a></li>
    <li><a href="./lab4CompOps.php" >Comparison Operators (Chapter 5)</a></li>
    <li><a href="./lab4LogOps.php" >Logical Operators (Chapter 5)</a></li>
    
</ol>



<?php 
// include the header
    include('footer.php');
?>