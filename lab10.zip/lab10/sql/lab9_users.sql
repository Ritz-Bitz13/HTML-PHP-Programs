/*
    Name: Martin Barber
    ID: 100368442
    Date: April 1st, 2022
*/

DROP TABLE IF EXISTS users;
CREATE TABLE users(
    ID VARCHAR(20) PRIMARY KEY,
    Password VARCHAR(15) NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    email_address VARCHAR(255) NOT NULL,
    enrol_date DATE NOT NULL,
    last_access DATE NOT NULL
);

INSERT INTO users(ID, Password, first_name, last_name, email_address, enrol_date, last_access)
    VALUES('jdoe', 'testpass', 'John', 'Doe', 'jdoe@durhamcollege.ca', '2022-1-1', '2022-2-1');
INSERT INTO users(ID, Password, first_name, last_name, email_address, enrol_date, last_access)
    VALUES(1234, 'password', 'James', 'Cunning', 'jcunning@durhamcollege.ca', '2022-1-4', '2022-2-2');
INSERT INTO users(ID, Password, first_name, last_name, email_address, enrol_date, last_access)
    VALUES(2345, '12345678', 'Martin', 'Barber', 'martin.barber13@hotmail.com', '2021-6-13', '2022-4-5');
INSERT INTO users(ID, Password, first_name, last_name, email_address, enrol_date, last_access)
    VALUES(3456, 'notmypassword', 'Michael', 'Marvin', 'Mikemarvin123@hotmail.com', '2021-6-9', '2022-3-4');

SELECT * FROM users ORDER BY last_name;