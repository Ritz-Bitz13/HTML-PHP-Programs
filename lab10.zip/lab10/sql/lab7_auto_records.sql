-- DROP'ping tables clear out any existing data
DROP TABLE IF EXISTS Automobiles;

-- CREATE the table, note that id has to be unique, and you must have a name
CREATE TABLE Automobiles(
	id INTEGER PRIMARY KEY,
	Make VARCHAR(15) NOT  NULL,
    Model VARCHAR(20) NOT NULL,
    Year INT NOT NULL,
    Owner VARCHAR(30) NOT NULL,
    MSRP FLOAT NOT NULL,
    Purchase_Date DATE NOT NULL
);
--ALTER TABLE actors OWNER TO userid;
--GRANT ALL ON automobiles TO faculty;
INSERT INTO Automobiles(id, Make, Model, Year, Owner, MSRP, Purchase_Date) VALUES(
	1,
	'Toyota',
    'Rav4 Hybrid XSE',
    2019,
    'Martin Barber',
    38999.99,
    '2019-05-22');
INSERT INTO Automobiles(id, Make, Model, Year, Owner, MSRP, Purchase_Date) VALUES(
	2,
	'Hyundai',
    'Elantra XS',
    2013,
    'Gillian Young',
    22999.99,
    '2012-04-30');
INSERT INTO Automobiles(id, Make, Model, Year, Owner, MSRP, Purchase_Date) VALUES(
	3,
	'Mazda',
    '3 Sport',
    2014,
    'Samantha Podpollock',
    28449.98,
    '2014-10-03');
INSERT INTO Automobiles(id, Make, Model, Year, Owner, MSRP, Purchase_Date) VALUES(
	4,
	'Dodge',
    'Ram 1500',
    2017,
    'Kenneth Barber',
    79498.98,
    '2018-07-14');
INSERT INTO Automobiles(id, Make, Model, Year, Owner, MSRP, Purchase_Date) VALUES(
	5,
	'Mazda',
    '5 Minivan',
    2016,
    'Kimberley Argue',
    29448.99,
    '2015-07-12');

SELECT make, model, year, MSRP
FROM automobiles
ORDER BY year ASC;

