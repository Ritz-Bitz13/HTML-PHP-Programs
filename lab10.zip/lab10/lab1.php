<?php
	$title = "Lab 1";
	$file = "lab1.php";
	$description = "Description: Lab 1: Basic XHTML Pages";
	$date = "Date: Jan 14th, 2022";
	$banner = "Lab 1: Basic XHTML Pages";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>
                <!--    Einstein's Relativity of every action has an equil and opposite reaction    -->
                <h3>Einstein's Relativity</h3>
                <p>For Einstein's Relativity formula you have to use the superscript(&lt;sup&gt;...&lt;/sup&gt;) and
                    italics
                    (&lt;i&gt;...&lt;/i&gt;). It is wrapped in heading 2 (&lt;h2&gt;...&lt;/h2&gt;) tags to make it
                    larger and bolder.
                    <b>NOTE: be careful with proper nesting to ensure the pages passes the XHTML validator. This line is
                        bolded
                        using the bold (&lt;b&gt;...&lt;/b&gt;) tags.
                    </b>
                </p>
                <!--    "<sup> make the text in this a "power" like 2^3    -->
                <h2><i>E = mc<sup>2</sup></i></h2>
                <hr />
                <!--    Heading 3 because we want the text size to be smaller than heading 2    -->
                <h3>Currency Conversion (Use of special characters)</h3>
                <p>
                    This will show the different currency symbols you can use and the difference in cost between a
                    Canadian dollar, American, Pound, Euro and Yen
                </p>
                <h2>$1.00CDN = $0.703USD = &pound;0.487 = &euro;0.651 = &yen;82.77</h2>
                <hr />
                <!--    Heading 3 because we want the text size to be smaller than heading 2 as it shows in the example I am to recreate    -->
                <h3>Code Snippet</h3>
                <p>
                    Here is a sample of code to write hello world in C++. Typing the code like the following will result
                    you a responce of hello world in the console.
                </p>
                <h2>
                    <!--    "<br/>" will break the line and continue on a new line   -->
                    <code>
                        #include &lt;iostream.h&gt;<br/>
                        int main()<br/>
                        {<br/>
                            <!--    &nbsp adds an extra space when adding an indent to show for example a code example  -->
                        &nbsp;&nbsp;&nbsp;   cout &lt;&lt; "Hello world!" &lt;&lt; endl;<br/>
                        &nbsp;&nbsp;&nbsp;   return 0;<br/>
                        }<br/>
                    </code>

                </h2>
                <hr />
                
                <!--    Heading 3 because we want the text size to be smaller than heading 2    -->
                <h3>Chemistry Equation</h3>
                <p>
                    This is a chemistry equation of one chemical becoming another
                </p>

                <!--    <sub> will make the characters in between it lower like in a chemistry equation.    -->
                <h2>2H<sub>2</sub> + O<sub>2</sub> => 2H<sub>2</sub>O + heat</h2>
                <hr />

                <!--    Heading 3 because we want the text size to be smaller than heading 2    -->
                <h3>List Example (order important)</h3>
                <p>
                    This section is showing how to create a list in a web page. This is where the order matters when
                    creating the list. As long as you follow step by step you will complete the task at hand.
                </p>
                <h2>
                    How to start a car:
                </h2>
                <!--    This is how you create an order list.("<ol>") This will create a list of items to complete in order -->
                <ol>
                    <!--    "<li>" will create a list of items depending on an order list or bullet points     -->
                    <li>Place key in the ignition</li>
                    <li>Depress the brake pedal</li>
                    <li>Turn the ignition key</li>
                </ol>
                <hr />

                <!--    Heading 3 because we want the text size to be smaller than heading 2 as it shows on the example   -->
                <h3>List Example (order unimportant)</h3>
                <p>This is showing how to properly show how to create a list on a web page. The order is not at all
                    important but it is just showing tasks that need to be done.
                </p>
                <h2>
                    Things to do before my trip
                </h2>

                <!--    This will create a list to be done but order does not matter, this will create bullet points ("<ul>") to give a list of items to do with no order    -->
                <ul>
                    <li >Re-new passport</li>
                    <li>Convert Currency</li>
                    <li>Print out reservations &amp; itineraries</li>
                    <li>Verify vaccinations are up-to-date</li>
                </ul>
                <?php 
    include('footer.php');
?>