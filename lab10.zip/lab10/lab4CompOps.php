<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Comparison Operators (Chapter 5)";
	$file = "lab4CompOps.php";
	$description = "Description: Comparison Operators (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Comparison Operators (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //inserting header
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<!--  Implementing the table to show the different Operators and giving an example -->
<table border="1px">
    <th>
        Operator
    </th>
    <th>
        Definition
    </th>

    <tr>
        <td>
            ==
        </td>
        <td>
            Equil to
        </td>
    </tr>
    <tr>
        <td>
            !=
        </td>
        <td>
            not equil to
        </td>
    </tr>
    <tr>
        <td>
            &gt;
        </td>
        <td>
            Greater than
        </td>
    </tr>
    <tr>
        <td>
            &lt;
        </td>
        <td>
            Less than
        </td>
    </tr>
    <tr>
        <td>
            &gt;=
        </td>
        <td>
            Greater than or equil to
        </td>
    </tr>
    <tr>
        <td>
            &lt;=
        </td>
        <td>
            Less than or equil to
        </td>
    </tr>
</table>

<?php

//declaring variables
$a = 21;
$b = 15;
//original variables in a statement
echo "<P>Original value of \$a is $a and \$b is $b</P>";

// Test 1: If variables are equil to
if ($a == $b) {
    echo "<P>TEST 1: \$a equals \$b</P>";
} else {
    echo "<P>TEST 1: \$a is not equal to \$b</P>";
}

// Test 2: If variables are not equil to
if ($a != $b) {
    echo "<P>TEST 2: \$a is not equal to \$b</P>";
} else {
    echo "<P>TEST 2: \$a is equal to \$b</P>";
}

// Test 3: If variable A is greater than variable B
if ($a > $b) {
    echo "<P>TEST 3: \$a is greater than \$b</P>";
} else {
    echo "<P>TEST 3: \$a is not greater than \$b</P>";
}

// Test 4: If variable A is less than variable B
if ($a < $b) {
    echo "<P>TEST 4: \$a is less than \$b</P>";
} else {
    echo "<P>TEST 4: \$a is not less than \$b</P>";
}

// Test 4: If variable A is greater than or equil to variable B
if ($a >= $b) {
    echo "<P>TEST 5: \$a is greater than or equal to \$b</P>";
} else {
    echo "<P>TEST 5: \$a is not greater than or equal to \$b</P>";
}

// Test 4: If variable A is less than or equil to variable B
if ($a <= $b) {
    echo "<P>TEST 6: \$a is less than or equal to \$b</P>";
} else {
    echo "<P>TEST 6: \$a is not less than or equal to \$b</P>";
}

?>


<!--            END OF MAIN CONTENT             -->
<!--  Inserting the footer  -->
<?php 
    include('footer.php');
?>


