<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Chapter 4: Exercise 1";
	$file = "lab4tag.php";
	$description = "Description: PHP Start and End Tags (Chapter 4)";
	$date = "Date: Feb 18th, 2022";
	$banner = "PHP Start and End Tags (Chapter 4)";
    $your_name = "Martin Barber";
    $year = "2022";
    //insert Header
	include('header.php');
?>

    <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
    <table border="2px" width="50%">
        <tr><th>Opening Tag</th> <th>Closing Tag</th></tr>
            
        <tr>
            <td>&lt;?php </td> <td> ?&gt; </td>
        </tr>
        
    </table>

        <!-- using the proper php tags -->
        <h4>Using &lt;?php ?&gt;</h4>
        <?php 
        echo "<p>This is a test using the first tag type.</p>"; 
        ?>

        <!-- Using the second tag for php -->
        <h4>Using &lt;? ?&gt;</h4>
        <?
        echo "<p>This is a test using the second tag type.</p>";
        ?>

        <!-- Using the script language that doesnt actually work -->
        <h4>Using &lt;script language="php"&gt;</h4>
        <script language="php">
        echo "<p>This is a test using the third tag type.</p>";
        </script>
    <!--            END OF MAIN CONTENT             -->

<?php 
//Insert Footer
    include('footer.php');
?>


