<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Using Constants 2 (Chapter 5)";
	$file = "lab4Constants2.php";
	$description = "Description: Using Constants 2 (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Using Constants 2 (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //include header
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show the different constants  -->
<p>
    <table>
        <th>Pre-Defined Constants</th>
        <tr>
            <td>
                <?php echo"__FILE__"; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo"__LINE__"; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo"PHP_VERSION"; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo"PHP_OS"; ?>
            </td>
        </tr>
    </table>

    <!--  Test the constants on the web page  -->
    <h3>Testing the Constants</h3>
    <table>
        <tr>
            <td>
                <?php echo "<br>This file is ".__FILE__; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo "<br>This is line number ".__LINE__; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo "<br>I am using ".PHP_VERSION; ?>
            </td>
        </tr>
        <tr>
            <td>
                <?php echo "<br>This test is being run on ".PHP_OS; ?>
            </td>
        </tr>
    </table>
</p>

                <!--            END OF MAIN CONTENT             -->

<?php 
//oinclude footer
    include('footer.php');
?>


