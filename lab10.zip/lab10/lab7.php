<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Lab 7: Database Intro";
	$file = "lab7.php";
	$description = "Description: This lab will introduce databases to be part of the php web page";
	$date = "Date: March 25th, 2022";
	$banner = "Lab 7: Database Intro";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<p>
    <a href="./lab7_bond_info.php">Lab 7: Bond Info</a><br/>
    <a href="./sql/lab7_bond_movies.sql">Lab 7: Bond Movie SQL</a><br/>
    <a href="./lab7_automobile_info.php">Lab 7: Automobile Info</a><br/>
    <a href="./sql/lab7_auto_records.sql">Lab 7: Automobile SQL</a><br/>


</p>


<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


