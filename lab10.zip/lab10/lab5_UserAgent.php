<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "User Agent Information";
	$file = "lab5_UserAgent.php";
	$description = "Description: This will use a built in function to display the users browser information";
	$date = "Date: March 4th, 2022";
	$banner = "Your Browser Information";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>


<p> This will use the built in function to get the User Agent being used to view the webpage. This shows the language encoding and platform being used. What browser type, version and the platform.
    <?php
    // This function will allow web page to get the users browser information and store it into a variable.
        $agent = getenv("HTTP_USER_AGENT");

        // This will show all the information to the webpage of the users Browser information.
        echo "<br/> <br/> You are using $agent.";
    ?>

</p>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


