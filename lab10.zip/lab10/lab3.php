<?php
	$title = "Lab 3";
	$file = "lab3.php";
	$description = "Description: Lab 3 Formatting and Layout with Styles";
	$date = "Date: Jan 29th, 2022";
	$banner = "Lab 3 - Formatting and Layout with Styles";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

                <p>
                    This lab 3 we will be be using a CSS form to alter parts of the web page so we dont need to clog up
                    the main page to alter fonts, colors, alignments,
                    formats, headings and many other alterations that can be done. By using a CSS you are able to put
                    all alterations in a seperate form that you can link
                    this to multiple web pages to keep teh same format throughout different pages so you dont have to
                    use the same changes on every page.
                </p>

                <hr />
                <!--    Selector 1    -->
                <h3>Format the Body</h3>
                <p>
                    By using a CSS form to alter the body you can change specific information so if you use this form on
                    multiple web pages you dont have to constantly change
                    each body to your likings. Items like the background colour of the webpage to the font colour can
                    all be altered so they match each webpage exactly so each
                    webpage is exactly the same.
                </p>
                <h2>Background colour and text colour</h2>
                <hr />


                <!--    Selector 2    -->
                <h3>Format the th</h3>
                <p>
                    When you alter the &lt;th&gt; of a table you can make the font more appealing than just bold and
                    aligned in the center. Changing the font, making
                    the text bolder and changing the colour can be one of many things you can do to make the heading of
                    the table more appealing.
                </p>
                <table id="example2">
                    <tr>
                        <th>Name</th>
                        <th>Number</th>
                    </tr>
                    <tr>
                        <td>Martin Barber</td>
                        <td>123234345</td>
                    <tr>
                        <td>Timmy Dongo</td>
                        <td>100234654</td>
                    </tr>
        </tr>
    </table>
    <hr />

    <!--    Selector 3    -->
    <h3>Format the td</h3>
    <p>
        When you alter the &lt;td&gt; of a table you can do the exact same thing as &lt;th&gt; to make the table look a
        little better. By changing the font, colour and
        other alterations you can highlight specific information when you need to.
    </p>
    <table id="example3">
        <tr>
            <th>Name</th>
            <th>Number</th>
        </tr>
        <tr>
            <td>Martin Barber</td>
            <td>123234345</td>
        <tr>
            <td>Timmy Dongo</td>
            <td>100234654</td>
        </tr>
        </tr>
    </table>
    <hr />

    <!--    Selector 4    -->
    <h3>Pseudo-Classes of the 'a' Elements</h3>
    <p>
        By using Pseudo-Classes you can use it to do specific things to links to other pages. For example you can change
        the link colour when it has not been
        visited before, highlighted when you hover the mouse over the link, alter the background colour or text when you
        click the link and when you have visited
        the link in the past. By using these methods you are able to know and understand more when you are going to
        click on a link.
    </p>
    <h2><a id="example-link" href="https://durhamcollege.ca/">Durham College</a></h2>
    <hr />


    <!--    Selector 5    -->
    <h3>Changing the background of certain rows of the Graph</h3>
    <p>
        By adding a class to the &lt;tr&gt; you can use these selected parts of the graph to alter it in any way you
        desire. For this example I altered
        certain &lt;tr&gt; in the graph to be part of a class that has been highlighted yellow to identify it more. If
        there is specific information that
        you want to show and catch the readers attention.
    </p>
    <table>
        <tr>
            <!--   Information about the tag    -->
            <th style="height: 30px;">Tag</th>
            <th>Description</th>
        </tr>
        <tr class="bgyellow">
            <!--   Information about the table    -->
            <td style="height: 30px;">&lt;table&gt;</td>
            <td>Denotes the start of an <b>HTML</b> table in a web page.</td>
        </tr>
        <tr>
            <!--   Information about the Table Row    -->
            <td style="height: 30px;">&lt;tr&gt;</td>
            <td>Denotes the start of a row in an HTML table (NOTE: these tags must exist inside
                &lt;table&gt; ... &lt;/table&gt;
                tags in order to be valid, and work correctly. </td>
        </tr>
        <tr class="bgyellow">
            <!--   Information about the Table Data    -->
            <td style="height: 30px;">&lt;td&gt;</td>
            <td>Denotes a cell (or <u>T</u>able <u>D</u>ata) in an HTML table (NOTE: these tags must exist
                inside
                &lt;tr&gt; ... &lt;/tr&gt; tags in order to be valid, and work correctly.</td>
        </tr>
        <tr>
            <!--   Information about the Table Heading    -->
            <td style="height: 30px;">&lt;th&gt;</td>
            <td>Very similar to the &lt;td&gt; tags described above but the text is bold and centered.</td>
        </tr>
        <tr class="bgyellow">
            <!--   Information about the caption    -->
            <td style="height: 30px;">&lt;caption&gt;</td>
            <td>Will place a caption on an HTML table (NOTE: this tag must be implemented right after the
                opening
                &lt;table&gt; tag in order to be valid and work correctly).
            </td>
        </tr>
    </table>
    <hr />


    <!--    Selector 6    -->
    <h3>Format the Paragraph</h3>
    <p id="ExampleParagraph">
        By formatting the paragraph you are able to alter all &lt;p&gt; to your own specifications. If you want to
        change the font style, colour or
        size. You can change it all in the CSS to your own personal choice. If you want to add specific rules to certain
        paragraphs then all you will
        need to do is add an "id" to the tab to alter a specific paragraph or if you want to do a group of them, a
        class.
    </p>
    <h2>Example Above</h2>
    <hr />


    <!--    Selector 7    -->
    <h3>Format the heading 2 in this example</h3>
    <p>
        When you format the different headings you are able to alter anything you like about the headings. For this
        example we have altered the
        colour of the text in the heading below. Changing the font family as well to make the text more appealing.
    </p>
    <h2 id="Example7">This heading itself is the example</h2>
    <hr />


    <!--    Selector 8    -->
    <h3>Moving image and text to the Right</h3>
    <p>
        By using the text-align on the CSS page you are able to align certain things to a specific location on the
        webpage. For the footnote for example the
        image and text are moved to the right side of the page so it matches the other web pages.
    </p>
    <h2>Example is shown at the bottom right of this page</h2>
    <hr />


    <!--    Selector 9    -->
    <h3>Format picture to center of the Area</h3>
    <p>
        By using the text-align: center, I am able to align the wolf picture at the top the web page to the center of
        the area. By doing this to each and
        every webpage you only have to have to format the photo location once in the CSS sheet. the resst of the time
        you just use a class in each location
        to format every photo needed to be center.
    </p>
    <h2>Example is shown in the wolf image above on the top Left.</h2>
    <hr />


    <!--    Selector 10    -->
    <h3>Format a list and alter it </h3>
    <p>
        By using &lt;li&gt; in the CSS, I am altering everything used in a list. I have centered it, changed the font, colours and the family of text.
        Anything can be done to the text that can be done to the list as well but you can make all the lists have the same properties so you dont fill
        the .html page with all the information.
    </p>
    <h2>
        <ul>
            <li>Re-new passport</li>
            <li>Convert Currency</li>
            <li>Print out reservations &amp; itineraries</li>
            <li>Verify vaccinations are up-to-date</li>
        </ul>
    </h2>
    <hr />

    </td>
    </tr>
    <tr>
        <?php 
        include('footer.php');
    ?>