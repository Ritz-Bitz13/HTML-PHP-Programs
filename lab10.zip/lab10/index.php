<!--
    Name:         Martin Barber
    Student ID:   100368442
    File Name:    index.html
    Date:         Janurary 14, 2022 : updated: Feb 18th, 2022
    Description:  
-->
<?php
	$title = "Home Page";
	$file = "index.php";
	$description = "Description: WEBD 2201 Home Page.";
	$date = "Date: Janurary 14th, 2022";
	$banner = "WEBD2201 Home Page";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->
                <!--    This is the paragraph that is required for lab 1, inside will have a link to WEBD2201 home page and durham college web site -->
                <p>This home page was designed as part of the course requirement for <a
                        href="http://opentech.durhamcollege.org/pufferd/webd2201/lectures.php">WEBD 2201</a>.
                    This is part of the Lab 1 Rubric. This course is offered at <a
                        href="https://durhamcollege.ca/">Durham College</a> located in North Oshawa, Ontario, Canada</p>

                <!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>