<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Simple Temperature Conversion";
	$file = "lab5_Simple_Temp_Convert.php";
	$description = "Description: This will Convert temperatures from Fahrenheit to Celcius by 10 degrees difference";
	$date = "Date: March 4th, 2022";
	$banner = "Simple Temperature Conversion";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<p>This is a Simple Temperature Conversion. As the Table is Created and the loop is being run through, it will do the calulation inside the Loop itself.
    Everytime the loop it run it will calculate (9.0/5.0*'VariableNameHere' + 32).
</p>

<table border="1px">
        <tr><th>celcius</th><th>fahrenheit</th></tr>
        <?php 
        // This is the for loop that creates the table and converts the Calcius number to Fahrenheit
        for ($i = -40; $i <= 100; $i = $i+10)
        {
            // This is the echo statement that displays the information in the table
            echo "<tr><td>$i</td><td>".(9.0/5.0*$i + 32)."</td></tr>";
        }
        ?>
    </table>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


