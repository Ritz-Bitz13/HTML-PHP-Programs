<?php
	$title = "Lab 7: Automobile Database";
	$file = "lab7_automobile_info.php";
	$description = "Description: This lab will introduce databases to be part of the php web page";
	$date = "Date: March 30th, 2022";
	$banner = "Lab 7: Database Intro";
	$your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>
<p>
This page utilizes several postgreSQL method calls.  Such as pg_connect(),
pg_query(), and pg_fetch_result().
</p>
<!-- setup the table -->
<table border="1">
	<tr>
		<th>ID </th>
		<th>Make</th>
		<th>Model</th>
		<th>Year</th>
		<th>Owner</th>
		<th>MSRP</th>
		<th>Purchase_Date</th>
	</tr>

<?php
$output = ""; //Set up a variable to store the output of the loop 
//connect
$conn = pg_connect("host=127.0.0.1 dbname=barberm_db user=barberm password=100368442" );

//N.B. replace the YOUR variables with your specific information
//NOTE: "host=localhost..." SHOULD work, but if there is a problem with the config on opentech, use 127.0.0.1 instead

//issue the query
$sql = "SELECT * FROM Automobiles
			ORDER BY id";
	$result = pg_query($conn, $sql);
	$records = pg_num_rows($result);

//generate the table
	for($i = 0; $i < $records; $i++){  //loop through all of the retrieved records and add to the output variable
		$output .= "\n\t<tr>\n\t\t<td>".pg_fetch_result($result, $i, "id")."</td>"; 
		$output .= "\n\t\t<td>".pg_fetch_result($result, $i, "Make")."</td>"; 
        $output .= "\n\t\t<td>".pg_fetch_result($result, $i, "Model")."</td>"; 
        $output .= "\n\t\t<td>".pg_fetch_result($result, $i, "Year")."</td>"; 
        $output .= "\n\t\t<td>".pg_fetch_result($result, $i, "Owner")."</td>"; 
        $output .= "\n\t\t<td>".pg_fetch_result($result, $i, "MSRP")."</td>"; 
        $output .= "\n\t\t<td>".pg_fetch_result($result, $i, "Purchase_Date")."</td>\n\t</tr>"; 
	}

	echo $output; //display the output
?>
</table>
<!-- end the table -->
<?php 
    include('footer.php');
?>