<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Using PHP Variables";
	$file = "lab5.php";
	$description = "Description: Using PHP Variablesd";
	$date = "Date: March 4th, 2022";
	$banner = "Chapter 6 - Using PHP Variables";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>
<p>Here are all the links included with Lab 5. From getting the remote address, User address, calculating number together and using functions to create a calculation in a table.
    Learning how to use and call functions is very important and will be used further into the course.
</p>

<ol>
    <!--  All the links to go to the other pages  -->
    <li><a href="./lab5_RemoteAddress.php" >Remote Address (Chapter 6)</a></li>
    <li><a href="./lab5_UserAgent.php">User Agent (Chapter 6)</a></li>
    <li><a href="./lab5_Calculate_form.php" >Calculate Form (Chapter 6)</a></li>
    <li><a href="./lab5_Calculate.php" >Calculate (Chapter 6)</a></li>
    <li><a href="./lab5_Simple_Temp_Convert.php" >Simple Temperature Conversion (Chapter 6)</a></li>
    <li><a href="./lab5_Function_Temp_Convert.php" >Function Temperature Conversion (Chapter 6)</a></li>
    
</ol>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


