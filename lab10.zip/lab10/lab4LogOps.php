<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Logical Operators (Chapter 5)";
	$file = "lab4LogOps.php";
	$description = "Description: Logical Operators (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Logical Operators (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //including the header
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<!--  Implementing the table to show the different Operators and giving an example -->
<table border="1px">
    <th>
        Operator
    </th>
    <th>
        Description
    </th>
    <tr>
        <td>
            ||
        </td>
        <td>
            Or operator: Either value must be true or meet the requirements to run the if statement
        </td>
    </tr>
    <tr>
        <td>
            &&
        </td>
        <td>
            And operator: Both values much be true or meet the requirements to work to run the if statement
        </td>
    </tr>
</table>

<?php

// Stating Variables
$degrees = "95";
$hot = "yes";

//Implementing If statement #1 where 1 or the other must be true to run the if statement
if (($degrees > 100) || ($hot == "yes")) {
    echo "<P>TEST 1: It's <strong>really</strong> hot!</P>";
} else {
    echo "<P>TEST 1: It's bearable.</P>";
}

//Implementing If statement #2 where both need to be true to run the If statekemt
if (($degrees > 100) && ($hot == "yes")) {
    echo "<P>TEST 2: It's <strong>really</strong> hot!</P>";
} else {
    echo "<P> TEST 2: It's bearable.</P>";
}





?>

<!--            END OF MAIN CONTENT             -->
<!--  Inserting the footer  -->
<?php 
    include('footer.php');
?>


