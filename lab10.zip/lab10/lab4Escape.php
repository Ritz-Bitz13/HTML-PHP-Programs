<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Escaping Your Code (Chapter 4)";
	$file = "lab4Escape.php";
	$description = "Description: Escaping Your Code (Chapter 4)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Escaping Your Code (Chapter 4)";
    $your_name = "Martin Barber";
    $year = "2022";
    //Insert Header
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
                <p>
                <table>
            <tr>
                <td>
                    Type the following in HTML
                </td>
            </tr>
            <tr>
                <td>
                    &lt;HTML&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Head&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Title&gt; Trying For Another Error  &lt;/Title&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/head&gt;
                </td>
            </tr>
            <td>
                    &lt;body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    Now enter the PHP script &lt;?php echo "&lt;? echo "&lt;P&gt;I think this is really "cool"! &lt;/P&gt;"; ?&gt;";
                </td>
            </tr>
        </table>

        <br/>
            <br/>
        <?
        // show off a statement
            echo "<P>I think this is really "cool"!</P>";
        ?> &lt;---- As you can see this error happens not adding 'php' after "&lt?" at the beginning of the script.


<!--  Make a table to show to make a html end  -->
        <table>
            <tr>
                <td>
                    Close off the html to make the documents Valid.
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/HTML&gt;
                </td>
            </tr>
        </table>
                </p>
                
                <!--            END OF MAIN CONTENT             -->

<?php 
//insert Footer
    include('footer.php');
?>


