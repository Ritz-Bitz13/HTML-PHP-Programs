<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  This will allow people from the database to login to the server
-->
<?php
	$title = "Database/PHP Lab";
	$file = "lab9.php";
	$description = "Description: This will get a user to login to the server";
	$date = "Date: April 6th, 2022";
	$banner = "Database/PHP Lab";
	$your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
    require('function.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->
<?php
$errors = "";
$output = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $login = $_POST['id'];
    $login = trim($login);

    //LOGIN VALIDATION
    if(!isset($login) || trim($login)=="")// If the input is empty
    {
        $errors.= "You must enter the user ID number to login. <br/>";
        $login = ""; // This will empty the textbox when there is an error
    } 

    // PASSWORD VALIDATION
    $password = $_POST['password'];
    $password = trim($password);

    if(!isset($password) || trim($password)=="")// If the input is empty
    {
        $errors.= "You must enter the password to login <br/>";
        $password = ""; // This will empty the textbox when there is an error
    } 


    // VALIDATION DO IT MYSELF
    if($errors == ""){
        $connection = db_connect();
        $sql = "SELECT * FROM users
                WHERE id = '".$login."' and password = '".$password."'";
        
        $result = pg_query($connection, $sql);
        if (pg_num_rows($result) > 0)
        {
            $fname = pg_fetch_result($result, 0, 'first_name');
            $lname = pg_fetch_result($result, 0, 'last_name');
            $email = pg_fetch_result($result, 0, 'email_address');
            $last_access = pg_fetch_result($result, 0, 'last_access');
            //The next line will update the last access in the database to the current date.
            $sql2 = "UPDATE users SET last_access='".date("Y-m-d",time())."'WHERE id ='".$login."'";
            pg_query($connection, $sql2);
            
            $output.= "Welcome back $fname $lname <br/>";
            $output.= "Our records show that your  <br/>";
            $output.= "email Address is: $email <br/>";
            $output.= "and you last accessed our system on $last_access  <br/>";

        }
        else{
            $errors.= "The user does not exist.";
        }
    }
    
}

?>

<h1>Lab 9: Login Page</h1>

<div>
    <h2><?php echo $errors; ?></h2>     
</div>
<div>
    <h3><?php echo $output; ?></h3>
</div>

<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post">

<h3>Please Log-in Below</h3>
<h5>Please enter your login information below to connect to the system.</h5>
<table>
    <tr>
        <td>
            Login ID
        </td>
        <td>
            <input type="text" id="id1" name="id"/>
        </td>
    </tr>
    <tr>
        <td>
            Password
        </td>
        <td>
            <input type="password" id="pw1" name="password"/>
        </td>
    </tr>
    <tr>
        <td>
            <input type="submit" value="Log In"/>
        </td>
        <td>
            <input type="reset" value="Reset"/>
        </td>
    </tr>
</table>

</form>


<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


