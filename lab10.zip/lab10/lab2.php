<?php
	$title = "Lab 2";
	$file = "lab3.php";
	$description = "Description: Lab 2 Working with HTML Tables";
	$date = "Date: Jan 28th, 2022";
	$banner = "Lab 2 - Working with HTML Tables";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>
                <!--    Paragraph about the Lab I am doing-->
                <p>This is lab #2. In this lab I will be giving a brief description about the new tags we have learned.
                    With the use of these new tags
                    we have been able to create large tables and fill them with information. This lab will have created
                    a single table to hold or organize
                    all the information. The second graph will show three books I have read that includes the title,
                    author, Year of Publication and
                    Description. The final graph will be a time table of my school schedule with all my classes
                    organized using column span and row span
                    to fill all the time slots my classes offer.
                </p>
                <!--    Table #1 Information about the tables and how to create them-->
                <table border="2px" align="center" width="60%">
                    <caption>HTML Table Tags</caption>
                    <tr>
                        <!--   Information about the tag    -->
                        <th style="height: 30px;">Tag</th>
                        <th>Description</th>
                    </tr>
                    <tr>
                        <!--   Information about the table    -->
                        <td style="height: 30px;">&lt;table&gt;</td>
                        <td>Denotes the start of an <b>HTML</b> table in a web page.</td>
                    </tr>
                    <tr>
                        <!--   Information about the Table Row    -->
                        <td style="height: 30px;">&lt;tr&gt;</td>
                        <td>Denotes the start of a row in an HTML table (NOTE: these tags must exist inside
                            &lt;table&gt; ... &lt;/table&gt;
                            tags in order to be valid, and work correctly. </td>
                    </tr>
                    <tr>
                        <!--   Information about the Table Data    -->
                        <td style="height: 30px;">&lt;td&gt;</td>
                        <td>Denotes a cell (or <u>T</u>able <u>D</u>ata) in an HTML table (NOTE: these tags must exist
                            inside
                            &lt;tr&gt; ... &lt;/tr&gt; tags in order to be valid, and work correctly.</td>
                    </tr>
                    <tr>
                        <!--   Information about the Table Heading    -->
                        <td style="height: 30px;">&lt;th&gt;</td>
                        <td>Very similar to the &lt;td&gt; tags described above but the text is bold and centered.</td>
                    </tr>
                    <tr>
                        <!--   Information about the caption    -->
                        <td style="height: 30px;">&lt;caption&gt;</td>
                        <td>Will place a caption on an HTML table (NOTE: this tag must be implemented right after the
                            opening
                            &lt;table&gt; tag in order to be valid and work correctly).
                        </td>
                    </tr>
                </table>
                <hr />
                <!--    Table #2 books I have read    -->
                <table border="2px" align="center" width="90%">
                    <tr>
                        <th width="20%">Title</th>
                        <th width="15%">Author</th>
                        <th width="10%">Year of Publication</th>
                        <th width="55%">Description</th>
                    </tr>
                    <tr>
                        <!--    Book #1: Watched the movie of the first one and had to learn what happened next so this was the first offical book I read    -->
                        <td>Hunger Games: Catching Fire</td>
                        <td>Tim O'Brian</td>
                        <td align="center">2009</td>
                        <td>After winning the hunger games last year. Katniss Everdeen must test her luck again when she
                            is thrown in
                            the hunger games yet again. This is the 3rd Quarter Quell and the stakes are high and risk
                            is even higher.
                            Can she survive the capitals game or will she die trying.</td>
                    </tr>
                    <tr>
                        <!--    Book #2: Read this book on a trip in Cuba while sitting by the ocean    -->
                        <td>Game of Thrones: A Song of Ice and Fire</td>
                        <td>George R. R. Martin</td>
                        <td align="center">1996</td>
                        <td>This book is the first of many taking place in a fictional place known as Westeros. In this
                            book King
                            Robert visits his friend Ned Stark to be his right hand assistant due to the mysterious
                            death of his last
                            assistant.
                        </td>
                    </tr>
                    <tr>
                        <!--    Book #3: The only harry potter book I read, Was the second offical book I read    -->
                        <td>Harry Potter and the Deathly Hallows</td>
                        <td>J. K. Rowling</td>
                        <td align="center">2007</td>
                        <td>Since the Death of Dumbledoor, Harry feels he is no longer safe at Hogwarts. His last hope
                            is to find the
                            horcruxes left by Lord Voldemort and destroy each and everyone of them. Only then can he
                            stop the devistation
                            being unleashed into his world.
                        </td>
                    </tr>
                </table>
                <hr />
                <!--     Table #3 My school schedule     -->
                <table border="2px" align="center" width="100%">
                    <!--   Making the table and setting width of each day while time gets a sliver of the %     -->
                    <tr>
                        <td></td>
                        <th width="19%">Monday</th>
                        <th width="19%">Tuesday</th>
                        <th width="19%">Wednesday</th>
                        <th width="19%">Thursday</th>
                        <th width="19%">Friday</th>
                    </tr>
                    <tr>
                        <!--   8:10am - 9:00am   Data base class from 8-10am on friday  -->
                        <td style="height: 50px;">8:10am - 9:00am</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td rowspan="2" bgcolor="blue" valign="top">DBAS 1201-04 <br />13048 Class <br /> 8:10pm -
                            10:00pm<br />
                            ONLINE ONLINE</td>
                    </tr>
                    <tr>
                        <!--   9:10am - 10:00am     -->
                        <td style="height: 50px;">9:10am - 10:00am</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--   10:10am - 11:00am     -->
                        <td style="height: 50px;">10:10am - 11:00am</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--   11:10am - 12:00pm     -->
                        <td style="height: 50px;">11:10am - 12:00pm</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--    12:10pm - 1:00pm  lunch time across the whole board   -->
                        <td style="height: 50px;">12:10pm - 1:00pm</td>
                        <td bgcolor="green" colspan="5" align="center">LUNCH</td>

                    </tr>
                    <tr>
                        <!--    1:10pm - 2:00pm    -->
                        <td style="height: 50px;">1:10pm - 2:00pm</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--    2:10pm - 3:00pm  Online course of NETD on Thursday  -->
                        <td style="height: 50px;">2:10pm - 3:00pm</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td rowspan="2" bgcolor="blue" valign="top">NETD 2202-04 <br />14051 Class <br /> 2:10pm -
                            3:00pm<br />
                            ONLINE ONLINE</td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--   3:10pm - 4:00pm    WEBD Class on Friday -->
                        <td style="height: 50px;">3:10pm - 4:00pm</td>
                        <td></td>

                        <td></td>
                        <td></td>
                        <td rowspan="2" bgcolor="blue" valign="top">WEBD 2201-03 <br />14621 Class <br /> 3:10pm -
                            5:00pm<br />
                            C-WING C309</td>
                    </tr>
                    <tr>
                        <!--    4:10pm - 5:00pm   Tuesday NETD and Wednesday/Thursday lunch time -->
                        <td style="height: 50px;">4:10pm - 5:00pm</td>
                        <td></td>
                        <td rowspan="2" bgcolor="blue" valign="top">NETD 2202-04 <br />14051 Class <br /> 4:10pm -
                            6:00pm<br />
                            B-WING 305</td>
                        <td bgcolor="green" colspan="2" align="center">SNACK</td>
                    </tr>
                    <tr>
                        <!--    5:10pm - 6:00pm  WEBD class on Wednesday  -->
                        <td style="height: 50px;">5:10pm - 6:00pm</td>
                        <td></td>

                        <td rowspan="2" bgcolor="blue" valign="top">WEBD 2201-03 <br />14621 Class <br /> 5:10pm -
                            7:00pm<br />
                            C-WING C306</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--    6:10pm - 7:00pm  MATH class tuesday and OOP class on Thursday  -->
                        <td style="height: 50px;">6:10pm - 7:00pm</td>
                        <td></td>
                        <td rowspan="3" bgcolor="blue" valign="top">MATH 1110-03 <br />13842 Class <br /> 6:10pm -
                            9:00pm<br />
                            C-WING: ONLINE</td>

                        <td rowspan="2" bgcolor="blue" valign="top">OOP 2200-12 <br />14128 Class <br /> 6:10pm -
                            8:00pm<br /> B-WING
                            B238</td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--    7:10pm - 8:00pm  DBAS on Monday and OOP on Wednesday  -->
                        <td style="height: 50px;">7:10pm - 8:00pm</td>
                        <td rowspan="2" bgcolor="blue" valign="top">DBAS 1201-04 <br />13048 Class <br /> 7:10pm -
                            9:00pm<br />
                            B-WING ONLINE</td>
                        <td rowspan="2" bgcolor="blue" valign="top">OOP 2200-12 <br />14128 Class <br /> 7:10pm -
                            9:00pm<br />
                            JUSTIC JW 207</td>
                        <td></td>
                    </tr>
                    <tr>
                        <!--    8:10pm - 9:00pm    -->
                        <td style="height: 50px;">8:10pm - 9:00pm</td>
                        <td></td>
                        <td></td>
                    </tr>

                </table>
                <hr />


            </td>
        </tr>
        <?php 
    include('footer.php');
?>