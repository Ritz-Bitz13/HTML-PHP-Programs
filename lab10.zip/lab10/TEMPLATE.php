<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "xxxxxxxxxx";
	$file = "xxxxxx.php";
	$description = "Description: xxxxxxxxxxxxxx";
	$date = "Date: xxxxxxxxxx, 2022";
	$banner = "xxxxxxxxxxxxxxxxx";
	$your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<p>Content</p>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


