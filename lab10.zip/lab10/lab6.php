<!--
    Name:         Martin Barber
    Student ID:   100368442
-->

<?php
	$title = "Self-Referring Forms w/ Data Validation";
	$file = "lab6.php";
	$description = "Description: User inputs starting, ending and increase for temperature conversion";
	$date = "Date: March 11, 2022";
	$banner = "Self-Referring Forms with Data Validation";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<?php 
function toF($c)
    {
        return 9.0/5.0*$c + 32;
    }

// Declare Variables 
define('MAX_ITERATIONS',100);
$start_temp = 2;
$end_temp = 10;
$increase = 2;
$check_increment = 0;
$placeholder = 0;
$errors = "";
$output = "";

// If the method sent in is a post then continue
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
     /* --------------------- Starting Value Validation ------------------------ */
    $start_temp = $_POST['startingNumber'];

    if(!isset($start_temp) || trim($start_temp)=="")// If the input is empty
	{
		$errors.= "You must enter a starting temperature <br/>";
	} 
	else if (!is_numeric($start_temp)) // Is the number entered a number?
	{
		$errors.= "The starting Temperature must be a number. You entered: $start_temp <br/>";
		$start_temp = ""; // This will empty the textbox when there is an error
	}
    /* ----------------END OF START VALUE VALIDATION--------------------------- */

     /* ------- Ending Value Validation -------- */
    $end_temp = $_POST['endingNumber'];

    if(!isset($end_temp) || trim($end_temp)=="")// If the input is empty
    {
        $errors.= "The end temperature has nothing in the box, please enter a number.<br/>";
    } 
    else if (!is_numeric($end_temp)) // Is the number entered a number?
    {
        $errors.= "The end temperature entered is not a number. you entered: $end_temp <br/>";
        $end_temp = ""; // This will empty the textbox when there is an error
    }
    /* ------------------END OF ENDING VALUE VALIDATION------------------------------ */

    // If the end number is less than the start number, this will switch the numbers and continue
    if ($end_temp < $start_temp)
    {
        $placeholder = $end_temp; // placeholder to hold the end temperature while the values switch
        $end_temp = $start_temp; // end_temp becomes start_temp
        $start_temp = $placeholder; //start_temp becomes the placeholder (end_temp)
    }



    /* --------------------- Incremental Value Validation -------------------------- */
    $increase = $_POST['incrementNumber'];

    if(!isset($increase) || trim($increase)=="")// If the input is empty
    {
        $errors.= "The increase text box is empty, please enter a number <br/>";
    } 
    else if (!is_numeric($increase)) // Is the number entered a number?
    {
        $errors.= "The increase text box is not a number. you entered: $increase <br/>";
        $increase = ""; // This will empty the textbox when there is an error
    }
    else if ($increase <0) 
	{
		$errors.= "The increase in temperature must be a positive number. You entered: ".$increase;
		$increase = ""; // This will empty the textbox when there is an error
	}
    /* ---------------------END OF INCREMENTAL VALIDATION------------------------------ */
    

    // If There are no errors, It will run the calculation to check if the increment will exceed the MAX_INCREMENT
    if ($errors == "")
    {
        $temp = $end_temp - $start_temp;
        $check_increment = $temp / $increase;
    }

    // Once the calculation is done, it will check against MAX_INCREMENT, if it is, it will cause an error and will not run the table because there will be too many rows.
    if ($check_increment > MAX_ITERATIONS)
    {
        $errors.= "You will be incrementing over 100 times, please make the increment number larger";
        $increase = ""; // This will empty the textbox when there is an error
    }

    /* -------  IF THERE IS NO ERRORS MAKE THE TABLE -------- */
    if($errors == "") // If there are no errors then do the formula
	{
        $output.="<table>";
        $output.="<tr><th>~Celcius~</th><th>~Fahrenheit~</th></tr>";
        for ($i = $start_temp; $i <= $end_temp; $i+=$increase)
        {
            $output.= "<tr><td>$i</td><td>".toF($i)."</td></tr>";
        }
        $output.="</table>";
    }
}

?>

<h3 id="errors"><?php echo $errors; ?></h3>

<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"> 
<p>
    <!--  This will create a textbox that will get a input to calculate with the second value  -->
    <label for="n1">Starting Temperature: </label>
    <input type="text" name="startingNumber" value="<?php echo $start_temp ?>" id="n1"/> <br/><br/>
    <!--  This will create a textbox that will get a input to calculate with the first value  -->
    <label for="n2">Ending Temperature: </label>
    <input type="text" name="endingNumber" value="<?php echo $end_temp ?>" id="n2"/> <br/><br/>
    <!--  This will create a textbox that will get a input to calculate with the first value  -->
    <label for="inc">Increment Value: </label>
    <input type="text" name="incrementNumber" value="<?php echo $increase ?>" id="inc"/> <br/><br/>

    <input type="submit" value="Submit"/>
</p>
    <div>
        <?php echo $output; ?>
    </div>
</form>

<?php 
    include('footer.php');
?>