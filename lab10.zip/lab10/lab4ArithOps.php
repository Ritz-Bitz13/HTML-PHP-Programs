<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Arithmetic Operators (Chapter 5)";
	$file = "lab4ArithOps.php";
	$description = "Description: Arithmetic Operators (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Arithmetic Operators (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    // insert Header
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<!--  Implementing the table to show the different Operators and giving an example -->
<table border="1px">
    <th>
        Operator
    </th>
    <th>
        Example
    </th>
    <th>
        Action
    </th>
    <tr>
        <td>
            +
        </td>
        <td>
            $b = $a + 3; 
        </td>
        <td>
            Adds Values
        </td>
    </tr>
    <tr>
        <td>
            -
        </td>
        <td>
            $b = $a - 3; 
        </td>
        <td>
            Subtracts Values
        </td>
    </tr>
    <tr>
        <td>
            *
        </td>
        <td>
            $b = $a * 3;
        </td>
        <td>
            Multiplies Values
        </td>
    </tr>
    <tr>
        <td>
            /
        </td>
        <td>
            $b = $a / 3; 
        </td>
        <td>
            Divide Values
        </td>
    </tr>
    <tr>
        <td>
            %
        </td>
        <td>
            $b = $a % 3; 
        </td>
        <td>
            Returns the modulus, or remainder
        </td>
    </tr>
</table>

<?php

// Stating Variables a and b
$a = 85;
$b = 24;

//Original values
echo "<P>Original value of \$a is $a and \$b is $b</P>";

// Adding the variables together
$c = $a + $b;
echo "<P>Added \$a and \$b and got $c</P>";

// subtracting the variables together
$c = $a - $b;
echo "<P>Subtracted \$b from \$a and got $c</P>";

// Multiplying the variables together
$c = $a * $b;
echo "<P>Multiplied \$a and \$b and got $c</P>";

// Dividing the variables together
$c = $a / $b;
echo "<P>Divided \$a by \$b and got $c</P>";

// getting the remainder
$c = $a % $b;
echo "<P>The modulus of \$a and \$b is $c</P>";



?>

<!--            END OF MAIN CONTENT             -->

<!--  Inserting the footer  -->
<?php 
    include('footer.php');
?>


