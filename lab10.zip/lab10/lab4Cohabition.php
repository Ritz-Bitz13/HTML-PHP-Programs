<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Code Cohabitation (Chapter 4)";
	$file = "lab4Cohabition.php";
	$description = "Description: Code Cohabitation (Chapter 4)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Code Cohabitation (Chapter 4)";
    $your_name = "Martin Barber";
    $year = "2022";
    //include header
	include('header.php');
?>

    <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
    <p> 
        <table>
            <tr>
                <td>
                    Type the following in HTML
                </td>
            </tr>
            <tr>
                <td>
                    &lt;HTML&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Head&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Title&gt; My first PHP Script  &lt;/Title&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/head&gt;
                </td>
            </tr>
            <td>
                    &lt;body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    Now enter the PHP script &lt;?php echo "&lt;P&gt;&lt;em&gt;Hello World! I'm using PHP!&lt;/em&gt;&lt;/P&gt;";
                </td>
            </tr>
        </table>

        
        <?php 
        // basic hello workd statement
        echo "<P><em>Hello World! I'm using PHP!</em></P>";
        ?></p>

<!--  Make a table to show to make a html ending  -->
        <table>
            <tr>
                <td>
                    Close off the html to make the documents Valid.
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/HTML&gt;
                </td>
            </tr>
        </table>
    
    <!--            END OF MAIN CONTENT             -->

<?php 
//include footer
    include('footer.php');
?>


