<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Lab 10: User Registration";
	$file = "lab10.php";
	$description = "Description: This will take the users information, and add it to the database";
	$date = "Date: Friday April 8th, 2022";
	$banner = "Lab 10: User Registration";
	$your_name = "Martin Barber";
    $year = "2022";
    ob_start();
	include('header.php');
    require('function.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->
<?php
if($_SERVER['REQUEST_METHOD']=="POST")
    {
        // Variables
        $id = $_POST['input_id'];
        $pass1 = $_POST['input_pass1'];
        $pass2 = $_POST['input_pass2'];
        $fname = $_POST['input_fname'];
        $lname = $_POST['input_lname'];
        $email = $_POST['input_email'];
        $today = date('Y-m-d');
        $enrolDate = $today;
        $lastAccess = $today;
        $errors = "";

        ////////////////////////////////////////////////////////////////////////
        //validation for Input ID
        if(!isset($id) || trim($id)=="")// If the input is empty
        {
            $errors.= "You must enter the user ID number to login. <br/>";
            $id = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($id) < MINIMUM_ID_LENGTH || strlen($id) > MAXIMUM_ID_LENGTH)
        {
            $errors.= "The ID must be 5 - 20 characters long. Please Re-enter your ID. <br/>";
            $id = "";
        }
        ////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////
        //Validation for Password
        if(!isset($pass1) || trim($pass1)=="")// If the input is empty
        {
            $errors.= "You must enter the password to create a login. <br/>";
            $pass1 = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($pass1) < MINIMUM_PASSWORD_LENGTH || strlen($pass1) > MAXIMUM_PASSWORD_LENGTH)
        {
            $errors.= "The password must be 6 - 15 characters long. Please Re-enter your password. <br/>";
            $pass1 = "";
        }
        ////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////
        // Validation for Confirm Password
        if(!isset($pass2) || trim($pass2)=="")// If the input is empty
        {
            $errors.= "You must enter the same password as above to create a login. <br/>";
            $pass2 = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($pass2) < MINIMUM_PASSWORD_LENGTH || strlen($pass2) > MAXIMUM_PASSWORD_LENGTH)
        {
            $errors.= "The password must be between 6 - 15 characters long. Please Re-enter your password. <br/>";
            $pass2 = "";
        }

        elseif ($pass1 != $pass2) // If pass1 does not = pass2
        {
            $errors.= "The password must match the first password. Please Re-enter your password. <br/>";
            $pass2 = "";
        }
        ////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////
        // Validation for first name
        if(!isset($fname) || trim($fname)=="")// If the input is empty
        {
            $errors.= "You must enter the user a first name to login. <br/>";
            $fname = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($fname) > MAX_FIRST_NAME_LENGTH)
        {
            // If the first name is over 20 characters it will fail
            $errors.= "The first name must be less than 20 characters long. Please enter a shorter first name. <br/>";
            $fname = "";
        }
        else if (is_numeric($fname)) // Is the number entered a number?
        {
            $errors.= "The first name must not be a number. <br/>";
            $fname = ""; // This will empty the textbox when there is an error
        }
        ////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////
        // Validation for last name
        if(!isset($lname) || trim($lname)=="")// If the input is empty
        {
            $errors.= "You must enter the user a last name to login. <br/>";
            $lname = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($lname) > MAX_LAST_NAME_LENGTH)
        {
            $errors.= "The last name must be less than 30 characters long. Please enter a shorter last name. <br/>";
            $lname = "";
        }
        else if (is_numeric($lname)) // Is the number entered a number?
        {
            $errors.= "The last name must not be a number. <br/>";
            $lname = ""; // This will empty the textbox when there is an error
        }
        ////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////
        // Validation for email address
        if(!isset($email) || trim($email)=="")// If the input is empty
        {
            $errors.= "You must enter the user an email to login. <br/>";
            $email = ""; // This will empty the textbox when there is an error
        } 
        elseif (strlen($email) > MAX_EMAIL_LENGTH)
        {
            // If the email is over 250 characters it will fail
            $errors.= "The email must be less than 250 characters long. Please enter a shorter email. <br/>";
            $email = "";
        }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $error.= $email. " is not a valid email address";
            $email = "";
        }
        ////////////////////////////////////////////////////////////////////////

        ?>
<div>
<h2><?php echo $errors; ?></h2>     
</div>
        <?php
        if ($errors == "") // if no errors, start entering the information to the database.
        {
            $conn = db_connect(); // connect to the database
            $sql = "INSERT INTO users (ID, Password, first_name, last_name, email_address, enrol_date, last_access)
            VALUES('$id', '$pass1', '$fname', '$lname', '$email', '$enrolDate', '$lastAccess');";
            $result = pg_query($conn, $sql);
            if($result)
            {
                header("Location: lab9.php"); // If everything clears, go to the lab9 page for the user to sign in
                ob_flush();
            }
                
        }
    }
?>
<p>
    This Lab will check the inputs the user names and if everything checks through validation, it will add it to the 
    current database and allow the user to enter the login screen from lab 9.
</p>

<form action="<?php $_SERVER['PHP_SELF']?>" method="post">
    <table>
        <tr>
            <!-- user enters their login ID they want -->
            <td>Login ID</td><td><input type="text" name="input_id"/></td></tr> 
        <tr>
            <!-- user inputs password -->
            <td>Password</td><td><input type="password" name="input_pass1"/></td></tr>
        <tr>
            <!-- confirming password -->
            <td>Confirm Password</td><td><input type="password" name="input_pass2"/></td></tr>
        <tr>
            <!-- User enters their first name -->
            <td>First Name</td><td><input type="text" name="input_fname"/></td></tr>
        <tr>
            <!-- User enters their last name-->
            <td>Last Name</td><td><input type="text" name="input_lname"/></td></tr>
        <tr>
            <!-- email address entered in this textbox -->
            <td>Email Address</td><td><input type="text" name="input_email"/></td></tr>
        <tr>
            <td>
                <!-- submits the information to be checked -->
                <input type="submit" value="Register"/>
            </td>
        <td>
            <!-- clears the textboxes -->
            <input type="reset" value="clear"/>
        </td>
        </tr>
    </table>
</form>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


