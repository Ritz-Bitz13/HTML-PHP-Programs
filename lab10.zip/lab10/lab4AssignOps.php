<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Assignment Operators (Chapter 5)";
	$file = "lab4CAssignOps.php";
	$description = "Description: Assignment Operators (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Assignment Operators (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //Insert Header
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->

                <!--  Implementing the table to show the different Operators and giving an example -->
       <table border= "1px">
           <th>Operator</th><th>Example</th><th>Action</th>
           <tr>
                <td align="center">
                    +=
                </td>
                <td>
                    $a += 3;
                </td>
                <td>
                    Changes the value of a variable to the current value plus the value on the right side.
                </td>
           </tr>
           <tr>
                <td align="center">
                    -=
                </td>
                <td>
                    $a -= 3;
                </td>
                <td>
                    Changes the value of a variable to the current value minus the value on the right side
                </td>
           </tr>
           <tr>
                <td align="center">
                    .=
                </td>
                <td>
                    $a .= "string";
                </td>
                <td>
                    Concatenates (adds on to) the value on the right side with the current value.
                </td>
           </tr>
       </table>

        <?php 
        
        //Original value is 100
        $origVar = 100;
        echo "<P>Original value is $origVar</P>";
        // add 25 to the original value
        $origVar += 25;
        echo "<P>Added a value, now it's $origVar</P>";
        // subtract 25 from the new value
        $origVar -= 12;
        echo "<P>Subtracted a value, now it's $origVar</P>";
        // take the calculated number and add chickens at the end
        $origVar .= " chickens";
        echo "<P>Final answer: $origVar</P>";


        ?>


                <!--            END OF MAIN CONTENT             -->

                <!--  Inserting the footer  -->
<?php 
    include('footer.php');
?>


