<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "PHP Variable and Value Types (Chapter 5)";
	$file = "lab4Types.php";
	$description = "Description: PHP Variable and Value Types (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "PHP Variable and Value Types (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //Include header
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
<p>
        <table>
            <tr>
                <td>
                    Type the following in HTML
                </td>
            </tr>
            <tr>
                <td>
                    &lt;HTML&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Head&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Title&gt; 
                    Printing Variables
                    &lt;/Title&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/head&gt;
                </td>
            </tr>
            <td>
                    &lt;body&gt;
                </td>
            </tr>
            <tr>
                <td>
                <br/>
                 Making 3 different Variables below: Integer, Float and String
                </td>
            </tr>
        </table>

        <br/>

        <?php 
        // Integer, float and string variables being shown
        $intVar = 123456;
        $floatVar = 1542.2232235;
        $stringVar = "This is a string.";
        echo "<P>integer: $intVar</P>";
        echo "<P>float: $floatVar</P>";
        echo "<P>string: $stringVar</P>";
        
        
        
        ?>

<!--  Make a table to show to make a html ending  -->
        <table>
            <tr>
                <td>
                    Close off the html to make the documents Valid.
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/HTML&gt;
                </td>
            </tr>
        </table>
                </p>

<!--            END OF MAIN CONTENT             -->

<?php 
//incluide Footer
    include('footer.php');
?>


