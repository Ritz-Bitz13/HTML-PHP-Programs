<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Calculation Form";
	$file = "lab5_Calcualte_form.php";
	$description = "Description: This is where you input the information to be displayed on the Calculated page";
	$date = "Date: March 4th, 2022";
	$banner = "Calculate Form";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>


    <!--  This will send the information to the lab5_Calculate page and display the results  -->
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post"> 

    <!--  This will create a textbox that will get a input to calculate with the second value  -->
    <p> Value 1: <input type="text" name="val1" size="10"/><br/></p>
    <!--  This will create a textbox that will get a input to calculate with the first value  -->
    <p> Value 2: <input type="text" name="val2" size="10"/> <br/></p>

    <!--  This will add a set of Radio Buttons to select what to do to the numbers  -->
    <p> Calculation:<br/>
    
    <input type="radio" name="calc" value="add" checked="checked"/> Add <br/>
    <input type="radio" name="calc" value="subtract"/> Subtract <br/>
    <input type="radio" name="calc" value="multiply"/> Multiply <br/>
    <input type="radio" name="calc" value="divide"/> Divide <br/><br/>
   

    <!--  This will create a button that will calculate the two numbers together  -->
    <input type="submit" name="submit" value="Calculate"/> 
 </p>
</form>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


