<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Commenting Your Code (Chapter 4)";
	$file = "lab4Comment.php";
	$description = "Description: Commenting Your Code (Chapter 4)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Commenting Your Code (Chapter 4)";
    $your_name = "Martin Barber";
    $year = "2022";
    //include header
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
                <p>
                <table>
            <tr>
                <td>
                    Type the following in HTML
                </td>
            </tr>
            <tr>
                <td>
                    &lt;HTML&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Head&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Title&gt; 
                    Code Comments
                    &lt;/Title&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/head&gt;
                </td>
            </tr>
            <td>
                    &lt;body&gt;
                </td>
            </tr>
            <tr>
                <td>
                <br/>
                <?php
                // making an echo showing different types of comments
                  echo  "// This is a simple PHP comment. <br/>
                    /* This is a C-style, multiline comment. You can make this as <br/>
                    long as you'd like. */ <br/>
                    # Used to shells? Use this kind of comment. <br/>";
?>
                </td>
            </tr>
        </table>

        <br/>


<!--  Make a table to show to make a html end -->
        <table>
            <tr>
                <td>
                    Close off the html to make the documents Valid.
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/HTML&gt;
                </td>
            </tr>
        </table>
                </p>
                
                <!--            END OF MAIN CONTENT             -->

<?php 
//oinclude footer
    include('footer.php');
?>


