<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Function Temperature Conversion";
	$file = "lab5_Function_Temp_Convert.php";
	$description = "Description: This is using a Function to convert the Calcius number to Fahrenheit";
	$date = "Date: March 4th, 2022";
	$banner = "Function Temperature Conversion";
    $your_name = "Martin Barber";
    $year = "2022";
	include('header.php');
?>

<!--          MAIN CONTENT INSIDE HERE        -->

<?php
    // This function will recieve a value for $c and convert that number to Fahrenheit using the conversion equation
    function toF($c)
    {
        return 9.0/5.0*$c + 32; // This converts the Celcius number to Fahrenheit
    }
    ?>

<p>This is a Function Temperature Conversion. As the Table is Created and the loop is being run through, it will jump out to the function to do the selected calculation.
    Everytime the loop it run it will jump to the function to calculate the Celcius to Fahrenheit conversion and then insert that number in the Fahrenheit column.
</p>

<table border="1px">

        <tr><th>celcius</th><th>fahrenheit</th></tr>
        <?php 
        // For loop to go through the table incrementing by 10 degrees everytime
        for ($i = -40; $i <= 100; $i = $i+10)
        {
            // In this echo statement the function toF is being called and the ($i) inside the function is the number that is being calculated.
            echo "<tr><td>$i</td><td>".toF($i)."</td></tr>";
            //c = $i f =" .tof($i)."<br/>";
        }
        ?>
    </table>

<!--            END OF MAIN CONTENT             -->

<?php 
    include('footer.php');
?>


