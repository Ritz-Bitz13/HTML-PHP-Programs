<!--
    Name:         Martin Barber
    Student ID:   100368442
    Description:  
-->
<?php
	$title = "Using Constants (Chapter 5)";
	$file = "lab4Constants1.php";
	$description = "Description: Using Constants (Chapter 5)";
	$date = "Date: Feb 24th, 2022";
	$banner = "Using Constants (Chapter 5)";
    $your_name = "Martin Barber";
    $year = "2022";
    //include the header
	include('header.php');
?>

                <!--          MAIN CONTENT INSIDE HERE        -->
<!--  Make a table to show to make a html start  -->
                <p>
        <table>
            <tr>
                <td>
                    Type the following in HTML
                </td>
            </tr>
            <tr>
                <td>
                    &lt;HTML&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Head&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;Title&gt; 
                    Printing Variables
                    &lt;/Title&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/head&gt;
                </td>
            </tr>
            <td>
                    &lt;body&gt;
                </td>
            </tr>
            <tr>
                <td>
                <br/>
                 Making a Constant below:
                </td>
            </tr>
        </table>

        <br/>

        <?php 
                // showing the constants
                define("MYCONSTANT", " ---> This is a test of defining constants. <---- ");
                echo MYCONSTANT;
                echo "<P></P>";
        ?>

<!--  Make a table to show to make a html end -->
        <table>
            <tr>
                <td>
                    Close off the html to make the documents Valid.
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/body&gt;
                </td>
            </tr>
            <tr>
                <td>
                    &lt;/HTML&gt;
                </td>
            </tr>
        </table>
                </p>
                <!--            END OF MAIN CONTENT             -->

<?php 
//include the footer
    include('footer.php');
?>


